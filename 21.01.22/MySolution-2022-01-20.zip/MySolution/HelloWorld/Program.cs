﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine();
Console.WriteLine("Hello, World!");

string name = "Hans Werner";
string upperName = name.ToUpper();
Console.WriteLine("Du heißt {0}", name);
Console.WriteLine("Du heißt " + name);
Console.WriteLine($"Du heißt {upperName}");
