﻿public class MainProgram
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Hello, World");
    }
}