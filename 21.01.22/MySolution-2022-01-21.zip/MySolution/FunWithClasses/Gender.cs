﻿public enum Gender
{
    Male,
    Female,
    Diverse,
}