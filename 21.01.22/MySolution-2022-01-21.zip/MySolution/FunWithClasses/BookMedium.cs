﻿public enum BookMedium
{
    None,
    Hardcover,
    Softcover,
    EBook,
    AudioBook
}